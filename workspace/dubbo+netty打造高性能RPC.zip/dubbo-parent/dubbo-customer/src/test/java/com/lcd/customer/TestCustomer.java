package com.lcd.customer;


import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lcd.api.TestService;

public class TestCustomer {
	public static void main(String[] args) throws Exception {

		@SuppressWarnings("resource")
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "servlet-context.xml" });
		context.start();

		TestService testService = (TestService) context.getBean("testService");
		String hello = testService.say("lichengdu");
		String dubbo = testService.testSayDubbo();
		System.out.println(hello);
		System.out.println(dubbo);
		System.in.read();
	}

}
