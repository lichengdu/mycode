package com.lcd.api;

public interface TestService {
	public String testSayDubbo();

	public String say(String name);
}
