package fuck.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class LetsFuck {
	public static void main(String[] args){
        ApplicationContext ctx=new FileSystemXmlApplicationContext("config/FuckSpringWeb.xml");
        FuckSpring fs=(FuckSpring) ctx.getBean("myBean");
        fs.show();
    }
}
