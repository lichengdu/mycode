package org.netty.server;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpContent;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpObject;
import io.netty.handler.codec.http.HttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http.QueryStringDecoder;
import io.netty.handler.codec.http.multipart.Attribute;
import io.netty.handler.codec.http.multipart.DefaultHttpDataFactory;
import io.netty.handler.codec.http.multipart.HttpDataFactory;
import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder.EndOfDataDecoderException;
import io.netty.handler.codec.http.multipart.InterfaceHttpData;
import io.netty.handler.codec.http.multipart.InterfaceHttpData.HttpDataType;
import io.netty.util.CharsetUtil;
import io.netty.util.ReferenceCountUtil;

public class MyServerHandler extends ChannelHandlerAdapter {
	Log log = LogFactory.getLog(MyServerHandler.class); 
	private String buf = "";
	private StringBuilder requestbuffer = new StringBuilder();
	private Map<String, String> origin_params;
	Gson gson = new Gson();
	private HttpPostRequestDecoder decoder;
	private static final HttpDataFactory factory = new DefaultHttpDataFactory(DefaultHttpDataFactory.MINSIZE); // Disk

	@Override
	public void channelReadComplete(ChannelHandlerContext ctx)
	{
		if (decoder != null)
		{
			decoder.cleanFiles();
		}
		ctx.flush();
	}
	
	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) {
		log.info("请求处理开始");
		buf = "";
		HttpRequest request  = (HttpRequest) msg;
		boolean isSSl=HttpServerConfig.getConfig().getSsl();
		String type="http";
		if(isSSl){
			type="https";
		}
		try {
			URI uri = new URI(request.uri());
			log.info("请求uri:"+uri.getPath());
			// 每次浏览器请求都会多一次这个请求的，直接return就可以了
			if (uri.getPath().equals("/favicon.ico"))
			{
				ctx.close();
				return;
			}
			System.out.println(uri.getPath());
			if (request.method().equals(HttpMethod.GET)) {
				log.info("get请求！");
				origin_params = getHttpGetParams(request);
				if(origin_params!=null){
					log.info("请求参数:"+origin_params);
					buf="你好:"+origin_params.get("name")+",你发起了"+type+"的get请求";
				}
			} else if (request.method().equals(HttpMethod.POST)) {
				log.info("Post请求！");
				Map<String, String> url_params = getHttpGetParams(request);
				if (msg instanceof HttpContent) {
					HttpContent httpContent = (HttpContent) msg;
					ByteBuf content = httpContent.content();
					String params = content.toString(CharsetUtil.UTF_8);
					requestbuffer.append(params);
					origin_params = getJsonParams(params);
					if (origin_params != null) {
						log.info("请求参数:"+origin_params);
						buf = "你好:" + origin_params.get("name") + ",你发起了" + type + "的post请求";
					}
					if (origin_params == null) {
						origin_params = getHttpPostParams(request);
						System.out.println(origin_params);
					}
				} else {
					origin_params = getHttpPostParams(request);
				}
				if (origin_params != null && url_params != null) {
					origin_params.putAll(url_params);
				}
			}
			writeResponse(request, ctx);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ReferenceCountUtil.release(msg);
		}
	}

	private Map<String, String> getHttpGetParams(HttpRequest request) {
		return getQueryParams(request.uri());
	}

	private Map<String, String> getQueryParams(String params) {
		QueryStringDecoder queryStringDecoder = new QueryStringDecoder(params);
		Map<String, String> paramsMap = new HashMap<String, String>();
		for (Entry<String, List<String>> p : queryStringDecoder.parameters().entrySet()) {
			String key = p.getKey().trim();
			List<String> vals = p.getValue();
			if (vals.size() > 0) {
				String value = vals.get(0);
				requestbuffer.append(key + ":" + value + "\n");
				paramsMap.put(key, value);
			}
		}
		return paramsMap;
	}

	private Map<String, String> getJsonParams(String params) {
		try {
			return gson.fromJson(params, new TypeToken<Map<String, String>>() {
			}.getType());
		} catch (Exception e) {
			return null;
		}
	}

	private Map<String, String> getHttpPostParams(HttpRequest request) throws Exception {
		Map<String, String> origin_params = new HashMap<String, String>();
		boolean decodeflag = false;
		decoder = new HttpPostRequestDecoder(factory, request);
		try {
			while (decoder.hasNext()) {
				InterfaceHttpData interfaceHttpData = decoder.next();
				if (interfaceHttpData != null) {
					try {
						/**
						 * HttpDataType有三种类型 Attribute, FileUpload,
						 * InternalAttribute
						 */
						if (interfaceHttpData.getHttpDataType() == HttpDataType.Attribute) {
							Attribute attribute = (Attribute) interfaceHttpData;
							String value = attribute.getValue();
							String key = attribute.getName();
							requestbuffer.append(key + ":" + value + "\n");
							origin_params.put(key, value);
						}
					} catch (Exception e) {
						System.out.println("请求参数异常！" + e.getMessage());
					} finally {
						interfaceHttpData.release();
					}
				}
			}
		} catch (EndOfDataDecoderException e1) {
			decodeflag = true;
		} catch (Exception e) {
			System.out.println("解释HTTP POST协议出错:" + e.getMessage());
			throw e;
		}
		if (decodeflag)
			return origin_params;
		return null;
	}

	/**
	 * 将结果返回给用户
	 * 
	 * @param currentObj
	 * @param ctx
	 * @return
	 */
	private void writeResponse(HttpObject currentObj, ChannelHandlerContext ctx) {
		FullHttpResponse response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1,
				currentObj.decoderResult().isSuccess() ? HttpResponseStatus.OK : HttpResponseStatus.BAD_REQUEST,
				Unpooled.copiedBuffer(buf.toString(), CharsetUtil.UTF_8));
		log.info(buf);
		ChannelFuture future = ctx.writeAndFlush(response);

		log.info("请求响应处理成功");
		future.addListener(ChannelFutureListener.CLOSE);
		//requestbuffer.append("\n---------------服务器主动关闭远程链接.---------------------");

	}
}